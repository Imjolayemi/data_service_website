<?php

$elect=mysqli_fetch_array(mysqli_query($db, "SELECT * FROM electprice WHERE id='1'"));

$waec=$getta['waec_price'];
$neco=$getta['neco_price'];

?>