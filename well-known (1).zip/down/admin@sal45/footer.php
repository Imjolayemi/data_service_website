
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Required Js -->
    <script src="static/assets/js/jquery.min.js"></script>
    <script src="static/assets/js/vendor-all.min.js"></script>
    <script src="static/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="static/assets/js/pcoded.min.js"></script>
   
    <!-- prism Js -->
    <script src="static/assets/plugins/prism/js/prism.min.js"></script>

    
<!-- pnotify Js -->
<script src="static/assets/plugins/pnotify/js/pnotify.custom.min.js"></script>


    <script src="static/assets/js/analytics.js"></script>

<script src="static/assets/plugins/data-tables/js/datatables.min.js"></script>
<script src="static/assets/js/pages/data-responsive-custom.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js"></script>
</body>

</html>
