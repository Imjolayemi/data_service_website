<?php

$elect=mysqli_fetch_array(mysqli_query($db, "SELECT * FROM electprice WHERE id='1'"));

$aedc=$elect['aedc'];
$ekedc=$elect['ekedc'];
$ikedc=$elect['ikedc'];
$ibedc=$elect['ibedc'];
$kaedco=$elect['kaedco'];
$kedco=$elect['kedco'];
$jed=$elect['jed'];
$phed=$elect['phed'];



?>