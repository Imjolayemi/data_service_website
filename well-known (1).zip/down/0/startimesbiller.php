<?php

if ($sell_package=="nova-weekly"){
  $variation_code="nova-weekly";
}

if ($sell_package=="nova-monthly"){
  $variation_code="nova";
}

if ($sell_package=="basic-weekly"){
  $variation_code="basic-weekly";
}

if ($sell_package=="basic-monthly"){
  $variation_code="basic";
}

if ($sell_package=="smart-weekly"){
  $variation_code="smart-weekly";
}

if ($sell_package=="smart-monthly"){
  $variation_code="smart";
}

if ($sell_package=="classic-weekly"){
  $variation_code="classic-weekly";
}

if ($sell_package=="classic-monthly"){
  $variation_code="classic";
}

if ($sell_package=="super-weekly"){
  $variation_code="super-weekly";
}

if ($sell_package=="super-monthly"){
  $variation_code="super";
}





?>