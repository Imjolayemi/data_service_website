<?php


  if ($sell_package=="dstv-padi"){
  $variation_code="dstv-padi";
}

if ($sell_package=="dstv-yanga"){
  $variation_code="dstv-yanga";
}

if ($sell_package=="dstv-confam"){
  $variation_code="dstv-confam";
}

if ($sell_package=="dstv-padi-extra"){
  $variation_code="padi-extra";
}

if ($sell_package=="dstv-yanga-extra"){
  $variation_code="yanga-extra";
}

if ($sell_package=="dstv-asia"){
  $variation_code="dstv6";
}

if ($sell_package=="dstv-confam-extra"){
  $variation_code="confam-extra";
}

if ($sell_package=="dstv-compact"){
  $variation_code="dstv79";
}

if ($sell_package=="dstv-compact-plus"){
  $variation_code="dstv7";
}

if ($sell_package=="dstv-premium"){
  $variation_code="dstv3";
}

if ($sell_package=="dstv-premium-asia"){
  $variation_code="dstv10";
}





?>