
 <!--"network_id": 1,-->
 <!--                                   "plan_id": 2,-->
 <!--                                   "phone_number": "08123456789",-->
 <!--                                   "ported": false-->
                    
                    <!--"quantity": 2,-->
                    <!--                "name_on_card": "Hello Telecom"                -->
<?php
// $mobile_no = "07083806229";
//  $plan_code = 24;
$url = "https://wazobianet.com/api/datacard/";
$ch = curl_init( $url );
# Setup request to send json via POST.
$payload = json_encode( array(
"network_id"=>"1",
"plan_id"=>"1",
"quantity"=>"2",
"name_on_card"=> "Ibrahim Ishaq"
));

curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Authorization: Token fc23f2c7913db5a8a3876d59c3fc34a8cc3f2166', 'Content-Type:application/json'));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
curl_close($ch);

echo $result;

// // Initialize cURL session
// $curl = curl_init();

// // Set mobile number and plan code
// $mobile_no = "07083806229";
// $plan_code = 24;

// // Set cURL options
// curl_setopt_array($curl, array(
//   CURLOPT_URL => 'https://wazobianet.com/api/data/',
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 0,
//   CURLOPT_FOLLOWLOCATION => true,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => 'POST',
//   CURLOPT_POSTFIELDS => json_encode(array(
//     "network_id" => 4,
//     "plan_id" => $plan_code,
//     "phone_number" => $mobile_no,
//     "Ported_number" => false,
//   )),
//   CURLOPT_HTTPHEADER => array(
//     'Authorization: Token fc23f2c7913db5a8a3876d59c3fc34a8cc3f2166',
//     'Content-Type: application/json'
//   ),
// ));

// // Execute cURL request and get response
// $response = curl_exec($curl);

// // Close cURL session
// curl_close($curl);

// // Print response
// echo $response;

// $xx=json_decode($response,true);



// $curl = curl_init();
// // $name= "Ibrahim";
// curl_setopt_array($curl, array(
//   CURLOPT_URL => 'https://wazobianet.com/api/datacard/',
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 0,
//   CURLOPT_FOLLOWLOCATION => true,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => 'POST',
//   CURLOPT_POSTFIELDS =>'{
//     "network_id": 1,
//     "plan_id": 1,
//     "quantity": 1,
// }',
//   CURLOPT_HTTPHEADER => array(
//     'Authorization: Token fc23f2c7913db5a8a3876d59c3fc34a8cc3f2166',
//     'Content-Type: application/json'
//   ),
// ));


// $response = curl_exec($curl);
// curl_close($curl);
// echo $response;